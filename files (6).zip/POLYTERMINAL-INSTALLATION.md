# 🚀 CEX ARBITRAGE SKILL 2.0 - POLYTERMINAL INSTALLATION

## For: https://github.com/MBIO1/polyterminal (Base44 App)

---

## 📦 FILES YOU NEED

1. **cex-arbitrage-skill-base44.js** - Core skill (11 KB)
2. **base44-integration-guide.js** - Integration examples (12 KB)

---

## ⚡ 5-MINUTE INSTALLATION

### Step 1: Clone your polyterminal repo

```bash
git clone https://github.com/MBIO1/polyterminal.git
cd polyterminal
npm install
```

### Step 2: Add skill to your project

Copy the files to your src folder:

```bash
# Create services folder if it doesn't exist
mkdir -p src/services

# Copy skill file
cp cex-arbitrage-skill-base44.js src/services/

# Copy integration guide
cp base44-integration-guide.js docs/
```

### Step 3: Create arbitrage service

Create `src/services/arbitrageSkill.js`:

```javascript
import CEXArbitrageSkillBase44 from './cex-arbitrage-skill-base44';

export const arbitrageSkill = new CEXArbitrageSkillBase44({
  maxLatencyMs: 50,
  stalePeriodMs: 5000,
  maxDailyLoss: 500,
  maxPositionSkew: 0.15,
  callback: (alert) => {
    console.log(`[${alert.severity}] ${alert.type}: ${alert.message}`);
  }
});

export default arbitrageSkill;
```

### Step 4: Create monitoring component

Create `src/components/ArbitrageMonitor.vue`:

```vue
<template>
  <div class="arbitrage-monitor">
    <div class="card market-health">
      <h3>🏥 Market Health</h3>
      <div class="value" :class="health.condition">{{ health.condition }}</div>
      <div class="advice">{{ health.advice }}</div>
      <div class="risk">Risk: {{ health.riskLevel }}</div>
    </div>

    <div class="card signals">
      <h3>📡 Signal Quality</h3>
      <div class="confidence">{{ signalHealth.confidence.toFixed(0) }}%</div>
      <div class="breakdown">
        <span class="healthy">✅ {{ signalHealth.healthy.length }}</span>
        <span class="stale">❌ {{ signalHealth.stale.length }}</span>
      </div>
    </div>

    <div class="card risk">
      <h3>💰 Risk Control</h3>
      <div class="health-score">Score: {{ report.risk.healthScore }}/100</div>
      <div class="daily-loss">${{ report.risk.dailyLossUSD.toFixed(2) }}</div>
    </div>

    <div class="card latency">
      <h3>⚡ Latency</h3>
      <div class="avg">{{ report.latency.average.toFixed(1) }}ms</div>
      <div class="p95">P95: {{ report.latency.p95.toFixed(1) }}ms</div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { arbitrageSkill } from '@/services/arbitrageSkill';

const health = ref({ condition: 'HEALTHY', advice: '', riskLevel: 'LOW' });
const signalHealth = ref({ healthy: [], stale: [], conflicting: [], confidence: 0 });
const report = ref({ risk: { healthScore: 100, dailyLossUSD: 0 }, latency: { average: 0, p95: 0 } });

onMounted(() => {
  setInterval(() => {
    health.value = arbitrageSkill.detectMarketHealth();
    signalHealth.value = arbitrageSkill.signalQuality;
    report.value = arbitrageSkill.getHealthReport();
  }, 100);
});
</script>

<style scoped>
.arbitrage-monitor {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
  padding: 1rem;
}

.card {
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 1.5rem;
  background: white;
}

.market-health .value {
  font-size: 2rem;
  font-weight: bold;
  padding: 0.5rem;
  border-radius: 4px;
  margin: 0.5rem 0;
  text-align: center;
}

.value.HEALTHY { background: #dcfce7; color: #166534; }
.value.VOLATILE { background: #fef3c7; color: #92400e; }
.value.UNCERTAIN { background: #fed7aa; color: #9a3412; }
.value.STALE { background: #fee2e2; color: #991b1b; }

.healthy { color: #10b981; font-weight: bold; }
.stale { color: #ef4444; font-weight: bold; }

.confidence {
  font-size: 1.5rem;
  font-weight: bold;
  color: #3b82f6;
}

.health-score {
  font-size: 1.25rem;
  font-weight: bold;
}

.daily-loss {
  font-size: 1rem;
  color: #666;
}

.avg {
  font-size: 1.5rem;
  font-weight: bold;
  color: #06b6d4;
}
</style>
```

### Step 5: Add to your app layout

In `src/App.vue` or main layout:

```vue
<template>
  <div id="app">
    <!-- Your existing content -->
    <ArbitrageMonitor />
  </div>
</template>

<script setup>
import ArbitrageMonitor from '@/components/ArbitrageMonitor.vue';
</script>
```

### Step 6: Add API endpoints (if using backend)

Create `src/api/arbitrage.js`:

```javascript
const API_BASE = process.env.VITE_BASE44_APP_BASE_URL;

export async function getMarketHealth() {
  const response = await fetch(`${API_BASE}/api/arbitrage/health`);
  return response.json();
}

export async function evaluateTrade(tradeData) {
  const response = await fetch(`${API_BASE}/api/arbitrage/evaluate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(tradeData)
  });
  return response.json();
}

export async function trackMarketData(exchangeData) {
  const response = await fetch(`${API_BASE}/api/arbitrage/track`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(exchangeData)
  });
  return response.json();
}
```

### Step 7: Use in your app

```javascript
import { arbitrageSkill } from '@/services/arbitrageSkill';
import { evaluateTrade, trackMarketData } from '@/api/arbitrage';

// Track market data
async function onMarketUpdate(data) {
  await trackMarketData({
    exchange: 'polymarket',
    latencyMs: data.latency,
    signals: data.signals
  });
}

// Evaluate trade
async function checkTrade(opportunity) {
  const evaluation = await evaluateTrade({
    buyExch: opportunity.buyExch,
    sellExch: opportunity.sellExch,
    bid: opportunity.bid,
    ask: opportunity.ask,
    size: opportunity.size,
    vol1: opportunity.volume1,
    vol2: opportunity.volume2
  });

  if (evaluation.shouldTrade && evaluation.healthCheck.condition === 'HEALTHY') {
    console.log('✅ Trade profitable and market healthy - execute!');
    // Execute trade
  } else {
    console.log('❌ Trade not profitable or market unstable - skip');
  }
}
```

---

## 🚀 DEPLOY TO BASE44

### Push to GitHub:

```bash
git add .
git commit -m "Add CEX Arbitrage Skill 2.0 integration"
git push origin main
```

### Publish in Base44:

1. Go to **https://base44.com**
2. Find your **polyterminal** project
3. Click **"Publish"**
4. Changes deploy automatically

---

## ✨ WHAT YOU GET

✅ Real-time market health monitoring
✅ Signal quality assessment
✅ Automatic staleness detection
✅ Risk control dashboard
✅ Latency tracking
✅ Trade profitability calculation
✅ Circuit breaker alerts

---

## 🎯 USAGE EXAMPLES

### Monitor in real-time:

```javascript
// Skill automatically updates every 100ms
const health = arbitrageSkill.detectMarketHealth();
console.log(health.condition); // HEALTHY, VOLATILE, UNCERTAIN, STALE
```

### Calculate trade profitability:

```javascript
const spread = arbitrageSkill.calculateRealSpread(
  'polymarket', 'binance',
  43500,  // bid
  43510,  // ask
  0.5,    // size
  500000, // volume1
  1000000 // volume2
);

console.log(spread.netSpreadBps); // Actual profit after all costs!
```

### Track position skew:

```javascript
const position = arbitrageSkill.trackPosition(
  'polymarket', 'BTCUSD', 'BUY', 0.5, 43500
);

if (position.isSkewed) {
  console.log('⚠️  Position is imbalanced - reduce size');
}
```

### Get comprehensive report:

```javascript
const report = arbitrageSkill.getHealthReport();
console.log(report);
// {
//   market: { condition, advice, riskLevel },
//   risk: { healthScore, dailyLoss },
//   signals: { healthy, stale, confidence },
//   latency: { average, p95 }
// }
```

---

## 🔍 KEY METRICS TO WATCH

- **Market Condition**: HEALTHY → VOLATILE → UNCERTAIN → STALE
- **Signal Confidence**: % of fresh, aligned signals
- **Health Score**: 100 = perfect, 0 = critical
- **Latency**: Should be <50ms
- **Net Spread**: Must be positive to trade

---

## 🚨 AUTOMATIC SAFETY FEATURES

Circuit breakers trigger on:
- ✅ Position skew >15%
- ✅ Daily loss >$500
- ✅ Market staleness >50%
- ✅ Signal confidence <50%
- ✅ Latency >50ms

When triggered → **Reduce position size** or **HALT trading**

---

## 📊 FILES CREATED

```
polyterminal/
├── src/
│   ├── services/
│   │   ├── cex-arbitrage-skill-base44.js  (new)
│   │   └── arbitrageSkill.js             (new)
│   ├── components/
│   │   └── ArbitrageMonitor.vue          (new)
│   ├── api/
│   │   └── arbitrage.js                  (new)
│   └── App.vue                           (modified)
└── docs/
    └── base44-integration-guide.js       (new)
```

---

## ✅ INSTALLATION CHECKLIST

- [ ] Cloned polyterminal repo
- [ ] Ran `npm install`
- [ ] Copied skill files to src/services/
- [ ] Created arbitrageSkill.js service
- [ ] Created ArbitrageMonitor.vue component
- [ ] Added component to App.vue
- [ ] Created API functions
- [ ] Tested locally: `npm run dev`
- [ ] Pushed to GitHub
- [ ] Published on Base44.com

---

## 🎉 DONE!

Your polyterminal app now has:
- **Enterprise-grade arbitrage monitoring**
- **Real-time market health tracking**
- **Automatic risk management**
- **Signal quality assessment**
- **Professional dashboard**

**Deploy and start monitoring!** 🚀

---

## 📞 SUPPORT

Read the complete guide: `base44-integration-guide.js`
All code is copy-paste ready!
